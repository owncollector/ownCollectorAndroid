package com.pagando.owncollector.data.remote.api

object Urls {
    const val BASE_URL = "http://owncollector.mainu.com.mx/api"
    const val LOGIN = "/login"
    const val REGISTER_USER = "/register"
    const val GET_POINTS_USER = "/getTrash/"
}
